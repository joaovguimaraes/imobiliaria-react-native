const data = [
  {
    address: 'AAAAAAAAA',
    type: 'AAAAAAAAA',
    price: 999,
    condominiumPrice: 999,
    rooms: 999,
    bathrooms: 999,
    image:
      'https://th.bing.com/th/id/OIP.ANbX-75zI_YlGZjuCrF7BQHaFj?pid=ImgDet&rs=1',
    occupied: 'Não',
  },
  {
    address: 'AAAAAAAAA',
    type: 'AAAAAAAAA',
    price: 999,
    condominiumPrice: 999,
    rooms: 999,
    bathrooms: 999,
    image:
      'https://th.bing.com/th/id/OIP.ANbX-75zI_YlGZjuCrF7BQHaFj?pid=ImgDet&rs=1',
    occupied: 'Não',
  },
  {
    address: 'AAAAAAAAA',
    type: 'AAAAAAAAA',
    price: 999,
    condominiumPrice: 999,
    rooms: 999,
    bathrooms: 999,
    image:
      'https://th.bing.com/th/id/OIP.ANbX-75zI_YlGZjuCrF7BQHaFj?pid=ImgDet&rs=1',
    occupied: 'Não',
  },
  {
    address: 'AAAAAAAAA',
    type: 'AAAAAAAAA',
    price: 999,
    condominiumPrice: 999,
    rooms: 999,
    bathrooms: 999,
    image:
      'https://th.bing.com/th/id/OIP.ANbX-75zI_YlGZjuCrF7BQHaFj?pid=ImgDet&rs=1',
    occupied: 'Não',
  },
];
export default data;
